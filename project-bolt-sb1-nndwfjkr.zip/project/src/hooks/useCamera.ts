import { useState, useRef, useCallback, useEffect } from 'react';
import type { CameraMode, RealDetection, AIStats, ModelStatus, ObstacleType } from '@/types';
import { COCO_TO_OBSTACLE } from '@/types';

interface UseCameraReturn {
  mode: CameraMode;
  stream: MediaStream | null;
  error: string | null;
  enabled: boolean;
  realDetections: RealDetection[];
  aiStats: AIStats;
  enable: () => Promise<void>;
  disable: () => void;
  videoRef: React.RefObject<HTMLVideoElement>;
}

const DEFAULT_STATS: AIStats = {
  fps: 0,
  inferenceMs: 0,
  objectCount: 0,
  topClass: null,
  topScore: 0,
  modelStatus: 'offline',
};

function estimateDistance(bboxHeight: number, videoHeight: number): number {
  if (bboxHeight <= 0 || videoHeight <= 0) return 50;
  const ratio = bboxHeight / videoHeight;
  return Math.max(1, Math.min(100, 8 / Math.max(ratio, 0.01)));
}

function mapCocoClass(cls: string): ObstacleType {
  return COCO_TO_OBSTACLE[cls] ?? 'rock';
}

export function useCamera(): UseCameraReturn {
  const [mode, setMode] = useState<CameraMode>('sim');
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [enabled, setEnabled] = useState(false);
  const [realDetections, setRealDetections] = useState<RealDetection[]>([]);
  const [aiStats, setAiStats] = useState<AIStats>(DEFAULT_STATS);

  const streamRef = useRef<MediaStream | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const modelRef = useRef<any>(null);
  const modelStatusRef = useRef<ModelStatus>('offline');
  const inferenceLoopRef = useRef<number>(0);
  const lastFrameTimeRef = useRef<number>(0);
  const fpsHistoryRef = useRef<number[]>([]);
  const runningRef = useRef<boolean>(false);

  const stop = useCallback(() => {
    runningRef.current = false;
    if (inferenceLoopRef.current) {
      cancelAnimationFrame(inferenceLoopRef.current);
      inferenceLoopRef.current = 0;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
    setStream(null);
    setEnabled(false);
    setMode('sim');
    setRealDetections([]);
    setAiStats({ ...DEFAULT_STATS, modelStatus: modelStatusRef.current });
  }, []);

  const runInferenceLoop = useCallback(async () => {
    if (!runningRef.current) return;
    const video = videoRef.current;
    const model = modelRef.current;

    if (!video || !model || video.readyState < 2) {
      inferenceLoopRef.current = requestAnimationFrame(runInferenceLoop);
      return;
    }

    try {
      const now = performance.now();
      const inferenceStart = performance.now();
      const predictions = await model.detect(video, 20, 0.45);
      const inferenceEnd = performance.now();
      const inferenceMs = inferenceEnd - inferenceStart;

      if (lastFrameTimeRef.current > 0) {
        const frameDelta = now - lastFrameTimeRef.current;
        const fps = 1000 / frameDelta;
        fpsHistoryRef.current.push(fps);
        if (fpsHistoryRef.current.length > 30) fpsHistoryRef.current.shift();
      }
      lastFrameTimeRef.current = now;
      const avgFps = fpsHistoryRef.current.length > 0
        ? fpsHistoryRef.current.reduce((a, b) => a + b, 0) / fpsHistoryRef.current.length
        : 0;

      const dets: RealDetection[] = predictions.map((p: any) => {
        const [x, y, w, h] = p.bbox;
        return {
          class: p.class,
          score: p.score,
          bbox: [x, y, w, h],
          obstacleType: mapCocoClass(p.class),
          distance: estimateDistance(h, video.videoHeight || 480),
        };
      });

      const topDet = dets.length > 0
        ? dets.reduce((max, d) => d.score > max.score ? d : max, dets[0])
        : null;

      setRealDetections(dets);
      setAiStats({
        fps: Math.round(avgFps * 10) / 10,
        inferenceMs: Math.round(inferenceMs),
        objectCount: dets.length,
        topClass: topDet?.class ?? null,
        topScore: topDet?.score ?? 0,
        modelStatus: 'ready',
      });
    } catch {
      // Keep trying on next frame
    }

    inferenceLoopRef.current = requestAnimationFrame(runInferenceLoop);
  }, []);

  const enable = useCallback(async () => {
    try {
      const s = await navigator.mediaDevices.getUserMedia({
        video: { width: 640, height: 480, facingMode: 'environment' },
        audio: false,
      });
      streamRef.current = s;
      setStream(s);
      setEnabled(true);
      setMode('live');
      setError(null);

      modelStatusRef.current = 'loading';
      setAiStats({ ...DEFAULT_STATS, modelStatus: 'loading' });

      try {
        const tf = await import('@tensorflow/tfjs');
        const cocoSsd = await import('@tensorflow-models/coco-ssd');
        await tf.setBackend('webgl');
        await tf.ready();
        const model = await cocoSsd.load({ base: 'lite_mobilenet_v2' });
        modelRef.current = model;
        modelStatusRef.current = 'ready';
        setAiStats({ ...DEFAULT_STATS, modelStatus: 'ready' });

        runningRef.current = true;
        lastFrameTimeRef.current = 0;
        fpsHistoryRef.current = [];
        inferenceLoopRef.current = requestAnimationFrame(runInferenceLoop);
      } catch (modelErr) {
        modelStatusRef.current = 'error';
        setAiStats({ ...DEFAULT_STATS, modelStatus: 'error' });
        const msg = modelErr instanceof Error ? modelErr.message : String(modelErr);
        setError(`AI model failed to load: ${msg}`);
      }
    } catch (e) {
      const err = e as Error;
      setError(err.name === 'NotAllowedError'
        ? 'Camera permission denied — using SIMULATION mode'
        : `Camera unavailable: ${err.message} — using SIMULATION mode`);
      setEnabled(true);
      setMode('sim');
    }
  }, [runInferenceLoop]);

  const disable = useCallback(() => {
    stop();
  }, [stop]);

  useEffect(() => {
    return () => {
      runningRef.current = false;
      if (inferenceLoopRef.current) cancelAnimationFrame(inferenceLoopRef.current);
      if (streamRef.current) streamRef.current.getTracks().forEach((t) => t.stop());
    };
  }, []);

  return {
    mode,
    stream,
    error,
    enabled,
    realDetections,
    aiStats,
    enable,
    disable,
    videoRef,
  };
}
