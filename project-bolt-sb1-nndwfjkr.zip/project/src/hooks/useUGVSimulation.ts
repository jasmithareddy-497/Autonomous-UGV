import { useState, useEffect, useRef, useCallback } from 'react';
import type {
  UGVState,
  Mission,
  Obstacle,
  Detection,
  Telemetry,
  LogEntry,
  GridCell,
  Vec2,
  GpsMode,
  EnvironmentMode,
  Landmark,
  MissionAnalytics,
  TerrainType,
  ObstacleType,
  ControlMode,
  ManualCommand,
  CommandEntry,
  CommandStatus,
} from '@/types';
import { ENVIRONMENT_CONFIGS, OBSTACLE_SAFETY_PRIORITY, OBSTACLE_IS_MOVING } from '@/types';
import {
  generateTerrain,
  generateObstacles,
  generateLandmarks,
  GRID_SIZE,
  CELL_SIZE,
  WORLD_SIZE,
  distance,
  angleTo,
  radToDeg,
  formatTime,
  formatDuration,
  gridToWorld,
  worldToGrid,
} from '@/sim/terrain';
import { aStarPath, simplifyPath } from '@/sim/pathfinding';
import { detectObstacles, analyzeTerrain, calculateConfidence, OBSTACLE_LABELS } from '@/sim/perception';
import {
  determineCommand,
  updateUGV,
  updateUGVManual,
  reachedTarget,
  obstacleAhead,
  calculateRisk,
  calculateAdaptiveSpeed,
} from '@/sim/vehicle';

let logId = 0;
let cmdId = 0;

export function useUGVSimulation() {
  const [terrain] = useState<GridCell[][]>(() => generateTerrain(42));
  const [obstacles, setObstacles] = useState<Obstacle[]>(() => generateObstacles(42));
  const [ugv, setUgv] = useState<UGVState>({
    pos: { x: 5, y: 5 },
    heading: 0,
    speed: 0,
    command: 'STOP',
  });
  const [mission, setMission] = useState<Mission>({
    pointA: { x: 5, y: 5 },
    pointB: null,
    status: 'IDLE',
    progress: 0,
    plannedPath: [],
    pathIndex: 0,
    trajectory: [],
    startTime: null,
  });
  const [detections, setDetections] = useState<Detection[]>([]);
  const [terrainAnalysis, setTerrainAnalysis] = useState<{ surface: string; confidence: number; terrainType: TerrainType }[]>([]);
  const [telemetry, setTelemetry] = useState<Telemetry>({
    x: 5,
    y: 5,
    heading: 0,
    speed: 0,
    distanceTraveled: 0,
    distanceRemaining: 0,
    gpsMode: 'DENIED',
    battery: 100,
    signal: 95,
    cpuLoad: 35,
    aiConfidence: 0.85,
    riskLevel: 0,
    collisionWarning: false,
    adaptiveSpeedLimit: 3.0,
    confidence: { obstacle: 0.9, terrain: 0.85, path: 0.88, localization: 0.82 },
    environment: 'daylight',
  });
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [gpsMode, setGpsMode] = useState<GpsMode>('DENIED');
  const [selectingMode, setSelectingMode] = useState<'destination' | null>(null);
  const [controlMode, setControlMode] = useState<ControlMode>('AUTONOMOUS');
  const [manualCommand, setManualCommand] = useState<ManualCommand | null>(null);
  const [speedScale, setSpeedScale] = useState(0.5);
  const [commandHistory, setCommandHistory] = useState<CommandEntry[]>([]);
  const [connected, setConnected] = useState(true);
  const [lastCommandTime, setLastCommandTime] = useState<string>('--:--:--');
  const [time, setTime] = useState(0);
  const [environment, setEnvironment] = useState<EnvironmentMode>('daylight');
  const [landmarks, setLandmarks] = useState<Landmark[]>(() => generateLandmarks(42));
  const [analytics, setAnalytics] = useState<MissionAnalytics | null>(null);

  const simState = useRef<{
    ugv: UGVState;
    mission: Mission;
    obstacles: Obstacle[];
    gpsMode: GpsMode;
    environment: EnvironmentMode;
    distanceTraveled: number;
    battery: number;
    demoMode: boolean;
    demoTimer: number;
    demoObstacleSpawned: boolean;
    replanCooldown: number;
    replanning: boolean;
    missionStartTime: number | null;
    obstaclesDetectedCount: number;
    routeReplans: number;
    maxRisk: number;
    collisions: number;
    speedSum: number;
    speedSamples: number;
    autoEStopTriggered: boolean;
    collisionCooldown: number;
    totalPathLength: number;
    controlMode: ControlMode;
    manualCommand: ManualCommand | null;
    speedScale: number;
    manualOverrideActive: boolean;
    obstacleBlockedForward: boolean;
  }>({
    ugv: { pos: { x: 5, y: 5 }, heading: 0, speed: 0, command: 'STOP' },
    mission: {
      pointA: { x: 5, y: 5 }, pointB: null, status: 'IDLE', progress: 0,
      plannedPath: [], pathIndex: 0, trajectory: [], startTime: null,
    },
    obstacles: generateObstacles(42),
    gpsMode: 'DENIED',
    environment: 'daylight',
    distanceTraveled: 0,
    battery: 100,
    demoMode: false,
    demoTimer: 0,
    demoObstacleSpawned: false,
    replanCooldown: 0,
    replanning: false,
    missionStartTime: null,
    obstaclesDetectedCount: 0,
    routeReplans: 0,
    maxRisk: 0,
    collisions: 0,
    speedSum: 0,
    speedSamples: 0,
    autoEStopTriggered: false,
    collisionCooldown: 0,
    totalPathLength: 0,
    controlMode: 'AUTONOMOUS',
    manualCommand: null,
    speedScale: 0.5,
    manualOverrideActive: false,
    obstacleBlockedForward: false,
  });

  const logRef = useRef<LogEntry[]>([]);
  const exploredCellsRef = useRef<Set<string>>(new Set());
  const terrainRef = useRef<GridCell[][]>(terrain);
  const animFrame = useRef<number>(0);
  const lastTime = useRef<number>(0);
  const timeRef = useRef<number>(0);
  const selectingModeRef = useRef<'destination' | null>(selectingMode);
  const landmarksRef = useRef<Landmark[]>(landmarks);
  const cmdHistoryRef = useRef<CommandEntry[]>([]);

  const addCommand = useCallback((
    command: ManualCommand | import('@/types').NavigationCommand,
    source: 'MANUAL' | 'AUTONOMOUS' | 'SYSTEM',
    status: CommandStatus,
    blockedReason?: string,
  ) => {
    const s = simState.current;
    const entry: CommandEntry = {
      id: cmdId++,
      command,
      source,
      status,
      timestamp: formatTime(),
      ugvPos: { ...s.ugv.pos },
      ugvHeading: s.ugv.heading,
      ugvSpeed: s.ugv.speed,
      blockedReason,
    };
    cmdHistoryRef.current = [...cmdHistoryRef.current, entry].slice(-30);
    setCommandHistory([...cmdHistoryRef.current]);
    setLastCommandTime(entry.timestamp);
  }, []);

  useEffect(() => {
    selectingModeRef.current = selectingMode;
  }, [selectingMode]);

  useEffect(() => {
    simState.current.environment = environment;
  }, [environment]);

  const addLog = useCallback((level: LogEntry['level'], source: string, message: string) => {
    const entry: LogEntry = {
      id: logId++,
      time: formatTime(),
      level,
      source,
      message,
    };
    logRef.current = [...logRef.current, entry].slice(-80);
    setLogs(logRef.current);
  }, []);

  // Initialize logs
  useEffect(() => {
    addLog('INFO', 'SYSTEM', 'UGV NAVCON v3.0 initialized — SIMULATION MODE');
    addLog('INFO', 'SYSTEM', 'Vision pipeline: YOLO-SIM v3 (simulated inference)');
    addLog('WARN', 'GPS', 'GPS DENIED — Visual SLAM active by default');
    addLog('INFO', 'SLAM', 'Visual odometry + feature matching ready');
    addLog('INFO', 'ENV', 'Environment mode: DAYLIGHT — clear visibility');
    addLog('INFO', 'SYSTEM', 'Click SET DESTINATION on map, then START MISSION');
    addLog('INFO', 'SYSTEM', 'UGV current position is the automatic start point');
    addLog('INFO', 'CMD', 'Command & Control module initialized — AUTONOMOUS mode');
    addLog('INFO', 'CMD', 'Switch to MANUAL mode for operator directional control');
  }, [addLog]);

  // GPS toggle event
  useEffect(() => {
    const handler = () => {
      setGpsMode((prev) => {
        const next = prev === 'ACTIVE' ? 'DENIED' : 'ACTIVE';
        simState.current.gpsMode = next;
        addLog('WARN', 'GPS', next === 'DENIED' ? 'GPS signal lost — switching to visual SLAM' : 'GPS signal restored');
        return next;
      });
    };
    window.addEventListener('toggle-gps', handler);
    return () => window.removeEventListener('toggle-gps', handler);
  }, [addLog]);

  // Compute total path length for progress calculation
  const computePathLength = useCallback((path: Vec2[]): number => {
    let len = 0;
    for (let i = 1; i < path.length; i++) {
      len += distance(path[i - 1], path[i]);
    }
    return len;
  }, []);

  // Plan path helper
  const planPath = useCallback((start: Vec2, goal: Vec2, obs: Obstacle[]): Vec2[] | null => {
    const startGrid = worldToGrid(start.x, start.y);
    const goalGrid = worldToGrid(goal.x, goal.y);
    const extraGridObs = obs
      .filter((o) => o.detected)
      .map((o) => ({
        x: o.pos.x / CELL_SIZE,
        y: o.pos.y / CELL_SIZE,
        radius: o.radius / CELL_SIZE + 1,
      }));

    const path = aStarPath(terrainRef.current, startGrid, goalGrid, extraGridObs);
    if (!path) {
      addLog('ERROR', 'PATH', 'No safe path found to destination');
      return null;
    }

    const simplified = simplifyPath(path);
    return simplified.map((p) => gridToWorld(p.x, p.y));
  }, [addLog]);

  // Map click handler
  const handleMapClick = useCallback((worldPos: Vec2) => {
    const mode = selectingModeRef.current;
    if (!mode) return;

    if (mode === 'destination') {
      simState.current.mission.pointB = worldPos;
      setMission((prev) => ({ ...prev, pointB: worldPos }));
      addLog('SUCCESS', 'MISSION', `Destination set at (${worldPos.x.toFixed(1)}, ${worldPos.y.toFixed(1)})`);
      setSelectingMode(null);
    }
  }, [addLog]);

  const startMissionInternal = useCallback((pointA: Vec2, pointB: Vec2, isDemo: boolean) => {
    const s = simState.current;

    // For demo: force GPS denied
    if (isDemo) {
      s.gpsMode = 'DENIED';
      setGpsMode('DENIED');
    }

    s.mission.pointA = pointA;
    s.mission.pointB = pointB;

    // Clear all old obstacles and start fresh
    s.obstacles = generateObstacles(42);
    s.demoObstacleSpawned = false;

    const path = planPath(pointA, pointB, s.obstacles);
    if (!path) return;

    const angleToB = angleTo(pointA, pointB);
    s.ugv = { pos: { ...pointA }, heading: angleToB, speed: 0, command: 'FORWARD' };
    s.mission.status = 'NAVIGATING';
    s.mission.plannedPath = path;
    s.mission.pathIndex = 1;
    s.mission.trajectory = [{ ...pointA }];
    s.mission.progress = 0;
    s.mission.startTime = performance.now();
    s.distanceTraveled = 0;
    s.obstaclesDetectedCount = 0;
    s.routeReplans = 0;
    s.maxRisk = 0;
    s.collisions = 0;
    s.speedSum = 0;
    s.speedSamples = 0;
    s.autoEStopTriggered = false;
    s.collisionCooldown = 0;
    s.demoMode = isDemo;
    s.demoTimer = 0;
    s.replanCooldown = 0;
    s.replanning = false;
    s.totalPathLength = computePathLength(path);

    // Mark all obstacles as undetected for fresh mission
    s.obstacles = s.obstacles.map((o) => ({ ...o, detected: false, confidence: 0, distance: 0 }));

    // Clear explored area and landmarks for fresh mission
    exploredCellsRef.current = new Set();
    landmarksRef.current = generateLandmarks(42);

    setMission({ ...s.mission });
    setUgv({ ...s.ugv });
    setObstacles([...s.obstacles]);
    setLandmarks([...landmarksRef.current]);
    setAnalytics(null);

    if (isDemo) {
      addLog('INFO', 'DEMO', '=== DEMO MISSION STARTED ===');
      addLog('WARN', 'GPS', 'GPS OFF — GPS-DENIED navigation mode');
      addLog('INFO', 'SLAM', 'Visual Odometry/SLAM activated — tracking position via camera');
      addLog('INFO', 'PERCEPTION', 'Camera perception + terrain analysis active');
    }
    addLog('SUCCESS', 'MISSION', `Navigation started: (${pointA.x.toFixed(0)},${pointA.y.toFixed(0)}) → (${pointB.x.toFixed(0)},${pointB.y.toFixed(0)})`);
    addLog('INFO', 'PATH', `Route planned: ${path.length} waypoints via A* — ${s.totalPathLength.toFixed(1)}m total`);
    addLog('INFO', 'SAFETY', 'Adaptive speed control engaged — terrain + risk aware');
  }, [planPath, addLog, computePathLength]);

  // Start mission
  const startMission = useCallback(() => {
    const s = simState.current;
    if (!s.mission.pointB) return;
    // Point A is always the UGV's current estimated position
    const startPoint = { ...s.ugv.pos };
    s.mission.pointA = startPoint;
    startMissionInternal(startPoint, s.mission.pointB, false);
  }, [startMissionInternal]);

  // Pause mission
  const pauseMission = useCallback(() => {
    simState.current.mission.status = 'PAUSED';
    setMission((prev) => ({ ...prev, status: 'PAUSED' }));
    addLog('WARN', 'MISSION', 'Navigation paused by operator');
  }, [addLog]);

  // Resume
  const resumeMission = useCallback(() => {
    simState.current.mission.status = 'NAVIGATING';
    setMission((prev) => ({ ...prev, status: 'NAVIGATING' }));
    addLog('INFO', 'MISSION', 'Navigation resumed');
  }, [addLog]);

  // Stop mission
  const stopMission = useCallback(() => {
    const s = simState.current;
    s.mission.status = 'IDLE';
    s.mission.plannedPath = [];
    s.mission.pathIndex = 0;
    s.mission.progress = 0;
    s.ugv.speed = 0;
    s.ugv.command = 'STOP';
    s.demoMode = false;

    setMission({ ...s.mission });
    setUgv({ ...s.ugv });
    addLog('WARN', 'MISSION', 'Navigation stopped by operator');
  }, [addLog]);

  // Reset mission
  const resetMission = useCallback(() => {
    const s = simState.current;
    // Keep UGV at its current position — it becomes the start point for the next mission
    s.mission = {
      pointA: { ...s.ugv.pos }, pointB: null, status: 'IDLE', progress: 0,
      plannedPath: [], pathIndex: 0, trajectory: [], startTime: null,
    };
    s.ugv.speed = 0;
    s.ugv.command = 'STOP';
    s.obstacles = generateObstacles(42);
    s.distanceTraveled = 0;
    s.demoMode = false;
    s.demoTimer = 0;
    s.demoObstacleSpawned = false;
    s.missionStartTime = null;
    s.totalPathLength = 0;
    exploredCellsRef.current = new Set();
    landmarksRef.current = generateLandmarks(42);
    s.obstaclesDetectedCount = 0;
    s.routeReplans = 0;
    s.maxRisk = 0;
    s.collisions = 0;

    setMission({ ...s.mission });
    setUgv({ ...s.ugv });
    setObstacles([...s.obstacles]);
    setLandmarks([...landmarksRef.current]);
    setAnalytics(null);
    addLog('INFO', 'SYSTEM', 'System reset — all mission data cleared');
  }, [addLog]);

  // Clear mission — keeps UGV at current position, allows new destination selection
  const clearMission = useCallback(() => {
    const s = simState.current;
    s.mission.pointA = { ...s.ugv.pos };
    s.mission.pointB = null;
    s.mission.status = 'IDLE';
    s.mission.progress = 0;
    s.mission.plannedPath = [];
    s.mission.pathIndex = 0;
    s.mission.trajectory = [];
    s.mission.startTime = null;
    s.ugv.speed = 0;
    s.ugv.command = 'STOP';
    s.demoMode = false;
    s.demoTimer = 0;
    s.demoObstacleSpawned = false;
    setMission({ ...s.mission });
    setUgv({ ...s.ugv });
    setAnalytics(null);
    addLog('INFO', 'MISSION', 'Mission cleared — UGV at current position, ready for new destination');
  }, [addLog]);

  // Emergency stop
  const emergencyStop = useCallback(() => {
    const s = simState.current;
    s.mission.status = 'EMERGENCY_STOP';
    s.ugv.speed = 0;
    s.ugv.command = 'STOP';
    s.demoMode = false;
    s.manualCommand = null;
    setManualCommand(null);

    setMission({ ...s.mission });
    setUgv({ ...s.ugv });
    addCommand('STOP', 'SYSTEM', 'EXECUTING');
    addLog('ERROR', 'SAFETY', 'EMERGENCY STOP ACTIVATED — All systems halted');
  }, [addCommand, addLog]);

  // Start demo
  const startDemo = useCallback(() => {
    const s = simState.current;
    startMissionInternal({ ...s.ugv.pos }, { x: 90, y: 90 }, true);
  }, [startMissionInternal]);

  // --- Command & Control ---

  // Switch control mode
  const setMode = useCallback((mode: ControlMode) => {
    const s = simState.current;
    s.controlMode = mode;
    setControlMode(mode);
    if (mode === 'MANUAL') {
      s.manualOverrideActive = true;
      // Pause autonomous navigation if running
      if (s.mission.status === 'NAVIGATING') {
        s.mission.status = 'PAUSED';
        setMission((prev) => ({ ...prev, status: 'PAUSED' }));
        addLog('WARN', 'CMD', 'MANUAL OVERRIDE — Autonomous navigation paused');
      }
      addLog('INFO', 'CMD', 'Control mode: MANUAL — operator directional control active');
    } else {
      s.manualOverrideActive = false;
      s.manualCommand = null;
      setManualCommand(null);
      addLog('INFO', 'CMD', 'Control mode: AUTONOMOUS — navigation system control');
    }
  }, [addLog]);

  // Send a manual movement command
  const sendManualCommand = useCallback((cmd: ManualCommand) => {
    const s = simState.current;
    if (s.mission.status === 'EMERGENCY_STOP') {
      addCommand(cmd, 'MANUAL', 'BLOCKED', 'Emergency stop active — command rejected');
      addLog('ERROR', 'CMD', `${cmd} command blocked — EMERGENCY STOP active`);
      return;
    }

    // Obstacle validation: block FORWARD if obstacle directly ahead
    if (cmd === 'FORWARD') {
      const obsAheadResult = obstacleAhead(s.ugv, s.obstacles, 7);
      if (obsAheadResult) {
        s.obstacleBlockedForward = true;
        addCommand(cmd, 'MANUAL', 'BLOCKED', 'Obstacle detected ahead');
        addLog('ERROR', 'CMD', 'Forward command blocked — obstacle detected ahead');
        return;
      }
      s.obstacleBlockedForward = false;
    }

    s.controlMode = 'MANUAL';
    s.manualCommand = cmd;
    setControlMode('MANUAL');
    setManualCommand(cmd);

    // Auto-pause autonomous if running
    if (s.mission.status === 'NAVIGATING') {
      s.mission.status = 'PAUSED';
      setMission((prev) => ({ ...prev, status: 'PAUSED' }));
    }

    const cmdLabels: Record<ManualCommand, string> = {
      FORWARD: 'Forward',
      BACKWARD: 'Backward',
      TURN_LEFT: 'Left turn',
      TURN_RIGHT: 'Right turn',
      ROTATE: 'Rotate / U-turn',
      STOP: 'Stop',
    };
    addCommand(cmd, 'MANUAL', 'SENT');
    addLog('INFO', 'CMD', `${cmdLabels[cmd]} command sent`);
  }, [addCommand, addLog]);

  // Resume navigation after emergency stop
  const resumeNavigation = useCallback(() => {
    const s = simState.current;
    if (s.mission.status !== 'EMERGENCY_STOP') return;
    s.mission.status = 'IDLE';
    s.ugv.speed = 0;
    s.ugv.command = 'STOP';
    s.manualCommand = null;
    setManualCommand(null);
    setMission({ ...s.mission });
    setUgv({ ...s.ugv });
    addCommand('STOP', 'SYSTEM', 'COMPLETED');
    addLog('INFO', 'CMD', 'Navigation resumed — Emergency stop cleared, systems ready');
  }, [addCommand, addLog]);

  // Set speed scale
  const changeSpeedScale = useCallback((val: number) => {
    simState.current.speedScale = val;
    setSpeedScale(val);
  }, []);

  // Toggle GPS
  const toggleGps = useCallback(() => {
    setGpsMode((prev) => {
      const next = prev === 'ACTIVE' ? 'DENIED' : 'ACTIVE';
      simState.current.gpsMode = next;
      addLog('WARN', 'GPS', next === 'DENIED' ? 'GPS signal lost — switching to visual SLAM' : 'GPS signal restored');
      return next;
    });
  }, [addLog]);

  // Set environment mode
  const setEnvironmentMode = useCallback((mode: EnvironmentMode) => {
    setEnvironment(mode);
    simState.current.environment = mode;
    const config = ENVIRONMENT_CONFIGS[mode];
    addLog('INFO', 'ENV', `Environment: ${config.label} — ${config.visibilityLabel}`);
  }, [addLog]);

  // Complete mission and compute analytics
  const completeMission = useCallback(() => {
    const s = simState.current;
    const missionTime = s.mission.startTime ? (performance.now() - s.mission.startTime) / 1000 : 0;
    const avgSpeed = s.speedSamples > 0 ? s.speedSum / s.speedSamples : 0;

    const result: MissionAnalytics = {
      missionTime,
      distance: s.distanceTraveled,
      obstaclesDetected: s.obstaclesDetectedCount,
      routeReplans: s.routeReplans,
      averageSpeed: avgSpeed,
      maxRisk: s.maxRisk,
      collisions: s.collisions,
      completed: true,
    };

    setAnalytics(result);
    addLog('SUCCESS', 'MISSION', `MISSION COMPLETED — ${formatDuration(missionTime)} | ${s.distanceTraveled.toFixed(1)}m | ${s.routeReplans} replans | ${s.obstaclesDetectedCount} obstacles | 0 collisions`);
  }, [addLog]);

  // Main simulation loop
  useEffect(() => {
    const loop = (now: number) => {
      const dt = Math.min(0.05, (now - lastTime.current) / 1000);
      lastTime.current = now;
      setTime((t) => t + dt);
      timeRef.current += dt;

      const s = simState.current;
      let newDetections: Detection[] = [];

      // Handle PAUSED and EMERGENCY_STOP — freeze the UGV but keep perception running for display
      if (s.mission.status === 'PAUSED' || s.mission.status === 'EMERGENCY_STOP') {
        s.ugv.speed = 0;
        s.ugv.command = 'STOP';
        newDetections = detectObstacles(s.ugv, s.obstacles, s.environment, 25);
      } else if (s.mission.status === 'NAVIGATING') {
        const path = s.mission.plannedPath;
        const pathIdx = s.mission.pathIndex;

        if (pathIdx < path.length) {
          const target = path[pathIdx];

          // Detect obstacles with environment effects
          newDetections = detectObstacles(s.ugv, s.obstacles, s.environment, 25);

          // Count newly detected obstacles
          const detectedIds = new Set(newDetections.map((d) => d.id));
          let newDetectedCount = 0;
          let changed = false;
          s.obstacles = s.obstacles.map((o) => {
            if (detectedIds.has(o.id) && !o.detected) {
              changed = true;
              newDetectedCount++;
              const det = newDetections.find((d) => d.id === o.id)!;
              const moving = OBSTACLE_IS_MOVING[o.type];
              addLog('WARN', 'PERCEPTION', `Detected ${det.label} at ${det.distance.toFixed(1)}m — conf ${(det.confidence * 100).toFixed(0)}%${moving ? ' [MOVING]' : ''}`);
              return { ...o, detected: true, confidence: det.confidence, distance: det.distance, moving, safetyPriority: OBSTACLE_SAFETY_PRIORITY[o.type] };
            }
            return o;
          });
          if (newDetectedCount > 0) s.obstaclesDetectedCount += newDetectedCount;
          if (changed) setObstacles([...s.obstacles]);

          // Check for obstacles ahead on current heading
          const obsAhead = obstacleAhead(s.ugv, s.obstacles, 7);
          if (obsAhead && s.replanCooldown <= 0 && !s.replanning) {
            s.mission.status = 'OBSTACLE_DETECTED';
            s.replanning = true;
            setMission({ ...s.mission });
            addCommand('STOP', 'AUTONOMOUS', 'EXECUTING');
            addLog('WARN', 'PERCEPTION', 'OBSTACLE DETECTED — Reducing speed, assessing situation');

            setTimeout(() => {
              const cur = simState.current;
              if (cur.mission.status !== 'OBSTACLE_DETECTED') {
                cur.replanning = false;
                return;
              }
              addLog('INFO', 'PATH', 'REPLANNING ROUTE — A* with dynamic obstacles');
              cur.mission.status = 'REPLANNING';
              cur.routeReplans++;
              setMission({ ...cur.mission });

              const newPath = planPath(cur.ugv.pos, cur.mission.pointB!, cur.obstacles);
              if (newPath && newPath.length > 0) {
                cur.mission.plannedPath = newPath;
                cur.mission.pathIndex = 1;
                cur.mission.status = 'NAVIGATING';
                cur.totalPathLength = computePathLength(newPath);
                addCommand('LEFT', 'AUTONOMOUS', 'COMPLETED');
                addLog('SUCCESS', 'PATH', `ALTERNATIVE ROUTE FOUND: ${newPath.length} waypoints — obstacle avoided`);
              } else {
                cur.mission.status = 'NAVIGATING';
                addLog('ERROR', 'PATH', 'No alternative route found — proceeding with caution');
              }
              cur.replanning = false;
              cur.replanCooldown = 3;
              setMission({ ...cur.mission });
            }, 1800);
          }

          // Navigate
          if (s.mission.status === 'NAVIGATING' && !s.replanning) {
            if (reachedTarget(s.ugv, target)) {
              const nextIdx = pathIdx + 1;
              if (nextIdx >= path.length) {
                s.ugv.speed = 0;
                s.ugv.command = 'STOP';
                s.mission.status = 'COMPLETED';
                s.mission.progress = 100;
                s.mission.pathIndex = nextIdx;
                // Point B becomes the UGV's new current position for the next mission
                s.mission.pointA = { ...s.ugv.pos };
                s.demoMode = false;
                setMission({ ...s.mission });
                setUgv({ ...s.ugv });
                completeMission();
              } else {
                s.mission.pathIndex = nextIdx;
              }
            } else {
              // Terrain analysis ahead
              const ugvGrid = worldToGrid(s.ugv.pos.x, s.ugv.pos.y);
              let terrainAhead: TerrainType = 'safe';
              const lookAheadGrid = 3;
              const fx = ugvGrid.x + Math.round(Math.cos(s.ugv.heading) * lookAheadGrid);
              const fy = ugvGrid.y + Math.round(Math.sin(s.ugv.heading) * lookAheadGrid);
              if (fx >= 0 && fx < GRID_SIZE && fy >= 0 && fy < GRID_SIZE) {
                terrainAhead = terrainRef.current[fy][fx].terrain;
              }

              // Calculate risk
              const { level: riskLevel, collisionImminent } = calculateRisk(s.ugv, s.obstacles, terrainAhead);
              if (riskLevel > s.maxRisk) s.maxRisk = riskLevel;

              // Auto emergency stop on imminent collision (very close)
              if (collisionImminent && s.collisionCooldown <= 0 && !s.autoEStopTriggered) {
                s.collisions++;
                s.collisionCooldown = 2;
                addLog('ERROR', 'SAFETY', `COLLISION WARNING — Risk ${riskLevel.toFixed(0)}% — Auto emergency stop engaged`);
                s.ugv.command = 'STOP';
                s.ugv.speed = 0;
                s.autoEStopTriggered = true;

                setTimeout(() => {
                  simState.current.autoEStopTriggered = false;
                }, 2000);
              }

              // Adaptive speed limit — terrain + risk + environment
              const speedLimit = calculateAdaptiveSpeed(terrainAhead, riskLevel, s.environment);

              // Determine command — pass obstacleAhead flag so UGV slows/stops naturally
              const cmd = determineCommand(s.ugv, target, obsAhead, riskLevel);
              // Log autonomous commands when they change
              if (cmd !== s.ugv.command) {
                const cmdLabels: Record<string, string> = {
                  FORWARD: 'Forward',
                  LEFT: 'Left turn',
                  RIGHT: 'Right turn',
                  REVERSE: 'Reverse',
                  STOP: 'Stop',
                  SLOW_DOWN: 'Slow down',
                };
                addCommand(cmd, 'AUTONOMOUS', 'EXECUTING');
              }
              s.ugv = updateUGV(s.ugv, target, cmd, dt, speedLimit);

              // Track trajectory
              const lastTraj = s.mission.trajectory[s.mission.trajectory.length - 1];
              if (!lastTraj || distance(lastTraj, s.ugv.pos) > 0.5) {
                s.mission.trajectory = [...s.mission.trajectory, { ...s.ugv.pos }];
              }

              // Distance and speed tracking
              s.distanceTraveled += Math.abs(s.ugv.speed) * dt;
              if (Math.abs(s.ugv.speed) > 0.1) {
                s.speedSum += Math.abs(s.ugv.speed);
                s.speedSamples++;
              }

              // Progress — based on distance to destination vs initial distance
              if (s.mission.pointB && s.totalPathLength > 0) {
                const distRemaining = distance(s.ugv.pos, s.mission.pointB);
                const initialDist = s.totalPathLength;
                s.mission.progress = Math.min(99, Math.max(0, (1 - distRemaining / initialDist) * 100));
              }

              // Update telemetry
              const conf = calculateConfidence(newDetections, s.environment, newDetections.length > 0);

              setTelemetry({
                x: s.ugv.pos.x,
                y: s.ugv.pos.y,
                heading: radToDeg(s.ugv.heading),
                speed: Math.abs(s.ugv.speed),
                distanceTraveled: s.distanceTraveled,
                distanceRemaining: s.mission.pointB ? distance(s.ugv.pos, s.mission.pointB) : 0,
                gpsMode: s.gpsMode,
                battery: s.battery,
                signal: Math.min(100, Math.max(50, 85 + Math.sin(now * 0.001) * 10)),
                cpuLoad: Math.min(100, 55 + Math.sin(now * 0.003) * 10 + Math.random() * 5),
                aiConfidence: conf.overall,
                riskLevel,
                collisionWarning: collisionImminent,
                adaptiveSpeedLimit: speedLimit,
                confidence: conf,
                environment: s.environment,
              });
            }

            // Update explored cells and landmarks
            const ugvGrid2 = worldToGrid(s.ugv.pos.x, s.ugv.pos.y);
            const exploreR = 4;
            for (let dy = -exploreR; dy <= exploreR; dy++) {
              for (let dx = -exploreR; dx <= exploreR; dx++) {
                const gx = ugvGrid2.x + dx;
                const gy = ugvGrid2.y + dy;
                if (gx >= 0 && gx < GRID_SIZE && gy >= 0 && gy < GRID_SIZE) {
                  if (dx * dx + dy * dy <= exploreR * exploreR) {
                    exploredCellsRef.current.add(`${gx},${gy}`);
                  }
                }
              }
            }

            // Observe nearby landmarks
            let landmarkChanged = false;
            landmarksRef.current = landmarksRef.current.map((lm) => {
              if (!lm.observed && distance(s.ugv.pos, lm.pos) < 15) {
                landmarkChanged = true;
                return { ...lm, observed: true };
              }
              return lm;
            });
            if (landmarkChanged) setLandmarks([...landmarksRef.current]);
          }
        }
      } else if (s.mission.status === 'OBSTACLE_DETECTED' || s.mission.status === 'REPLANNING') {
        newDetections = detectObstacles(s.ugv, s.obstacles, s.environment, 25);
        // Gradually decelerate the UGV while assessing the obstacle
        s.ugv = updateUGV(s.ugv, s.ugv.pos, 'STOP', dt, 0);
      } else if (s.controlMode === 'MANUAL' && s.manualCommand && s.mission.status === 'IDLE') {
        // Manual control — operator drives the UGV directly
        newDetections = detectObstacles(s.ugv, s.obstacles, s.environment, 25);

        // Re-validate FORWARD against obstacles each frame
        if (s.manualCommand === 'FORWARD' && obstacleAhead(s.ugv, s.obstacles, 7)) {
          if (!s.obstacleBlockedForward) {
            s.obstacleBlockedForward = true;
            addCommand('FORWARD', 'MANUAL', 'BLOCKED', 'Obstacle detected ahead');
            addLog('ERROR', 'CMD', 'Forward command blocked — obstacle detected ahead');
          }
          s.ugv = updateUGVManual(s.ugv, 'STOP', dt, 0);
        } else {
          if (s.obstacleBlockedForward && s.manualCommand === 'FORWARD') {
            s.obstacleBlockedForward = false;
          }
          s.ugv = updateUGVManual(s.ugv, s.manualCommand, dt, s.speedScale);
        }

        // Track trajectory and distance in manual mode
        const lastTraj = s.mission.trajectory[s.mission.trajectory.length - 1];
        if (!lastTraj || distance(lastTraj, s.ugv.pos) > 0.5) {
          s.mission.trajectory = [...s.mission.trajectory, { ...s.ugv.pos }];
        }
        s.distanceTraveled += Math.abs(s.ugv.speed) * dt;

        // Update explored cells
        const ugvGrid2 = worldToGrid(s.ugv.pos.x, s.ugv.pos.y);
        const exploreR = 4;
        for (let dy = -exploreR; dy <= exploreR; dy++) {
          for (let dx = -exploreR; dx <= exploreR; dx++) {
            const gx = ugvGrid2.x + dx;
            const gy = ugvGrid2.y + dy;
            if (gx >= 0 && gx < GRID_SIZE && gy >= 0 && gy < GRID_SIZE) {
              if (dx * dx + dy * dy <= exploreR * exploreR) {
                exploredCellsRef.current.add(`${gx},${gy}`);
              }
            }
          }
        }
      }

      // Terrain analysis for display
      const terrainResult = analyzeTerrain(s.ugv, terrainRef.current as any, s.environment);
      setTerrainAnalysis(terrainResult.map((r) => ({
        surface: r.surface,
        confidence: r.confidence,
        terrainType: r.terrainType,
      })));

      // Mark terrain explored
      for (const key of exploredCellsRef.current) {
        const [gx, gy] = key.split(',').map(Number);
        const t = terrainRef.current;
        if (t[gy] && t[gy][gx]) t[gy][gx].explored = true;
      }

      // Battery drain
      s.battery = Math.max(0, s.battery - (s.ugv.speed > 0 ? 0.003 : 0.0005));

      // Decrement cooldowns
      if (s.replanCooldown > 0) s.replanCooldown -= dt;
      if (s.collisionCooldown > 0) s.collisionCooldown -= dt;

      // Update React state every frame
      setUgv({ ...s.ugv });
      setMission({ ...s.mission });
      setDetections(newDetections);

      // Update telemetry for non-navigating states
      if (s.mission.status !== 'NAVIGATING' || s.replanning) {
        const conf = calculateConfidence(newDetections, s.environment, newDetections.length > 0);
        const riskInfo = calculateRisk(s.ugv, s.obstacles, 'safe');
        setTelemetry({
          x: s.ugv.pos.x,
          y: s.ugv.pos.y,
          heading: radToDeg(s.ugv.heading),
          speed: Math.abs(s.ugv.speed),
          distanceTraveled: s.distanceTraveled,
          distanceRemaining: s.mission.pointB ? distance(s.ugv.pos, s.mission.pointB) : 0,
          gpsMode: s.gpsMode,
          battery: s.battery,
          signal: Math.min(100, Math.max(50, 85 + Math.sin(now * 0.001) * 10)),
          cpuLoad: Math.min(100, (s.mission.status === 'NAVIGATING' ? 55 : 30) + Math.sin(now * 0.003) * 10 + Math.random() * 5),
          aiConfidence: conf.overall,
          riskLevel: riskInfo.level,
          collisionWarning: riskInfo.collisionImminent,
          adaptiveSpeedLimit: calculateAdaptiveSpeed('safe', riskInfo.level, s.environment),
          confidence: conf,
          environment: s.environment,
        });
      }

      // Demo: spawn dynamic obstacle after enough movement
      if (s.demoMode && s.mission.status === 'NAVIGATING' && !s.demoObstacleSpawned) {
        s.demoTimer += dt;
        // Wait until UGV has moved ~25% of the path and had time to demonstrate normal navigation
        if (s.mission.progress > 25 && s.demoTimer > 6) {
          // Find a point on the current path ahead of the UGV
          const aheadIdx = Math.min(s.mission.pathIndex + 3, s.mission.plannedPath.length - 1);
          const aheadPos = s.mission.plannedPath[aheadIdx];
          if (aheadPos) {
            // Place obstacle directly on the path to force a replan
            const newObs: Obstacle = {
              id: `demo-obs-${Date.now()}`,
              type: 'rock',
              pos: { x: aheadPos.x, y: aheadPos.y },
              radius: 3.5,
              detected: false,
              confidence: 0,
              distance: 0,
              dynamic: true,
              moving: false,
              safetyPriority: 1,
              spawnTime: timeRef.current,
            };
            s.obstacles = [...s.obstacles, newObs];
            setObstacles([...s.obstacles]);
            s.demoObstacleSpawned = true;
            addLog('WARN', 'ENV', 'New obstacle detected on planned route — rock formation blocking path');
          }
        }
      }

      animFrame.current = requestAnimationFrame(loop);
    };

    lastTime.current = performance.now();
    animFrame.current = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animFrame.current);
  }, [addLog, planPath, completeMission, computePathLength]);

  const exploredArea = exploredCellsRef.current.size * CELL_SIZE * CELL_SIZE;
  const totalArea = WORLD_SIZE * WORLD_SIZE;
  const loopClosures = landmarksRef.current.filter((l) => l.type === 'loop' && l.observed).length;
  const featurePoints = landmarksRef.current.filter((l) => l.observed).length;
  const totalLandmarks = landmarksRef.current.length;
  const observedLandmarks = landmarksRef.current.filter((l) => l.observed).length;

  // Inject obstacle from camera detection — places an obstacle ahead of the UGV
  // so the navigation system can detect and replan around it
  const injectObstacle = useCallback((type: ObstacleType, confidence: number) => {
    const s = simState.current;
    if (s.mission.status !== 'NAVIGATING' && s.mission.status !== 'IDLE') return;

    const aheadDist = 15;
    const obsPos = {
      x: Math.max(2, Math.min(98, s.ugv.pos.x + Math.cos(s.ugv.heading) * aheadDist)),
      y: Math.max(2, Math.min(98, s.ugv.pos.y + Math.sin(s.ugv.heading) * aheadDist)),
    };

    const newObs: Obstacle = {
      id: `cam-obs-${Date.now()}`,
      type,
      pos: obsPos,
      radius: 3.5,
      detected: false,
      confidence: 0,
      distance: 0,
      dynamic: true,
      moving: OBSTACLE_IS_MOVING[type],
      safetyPriority: OBSTACLE_SAFETY_PRIORITY[type],
      spawnTime: timeRef.current,
    };

    s.obstacles = [...s.obstacles, newObs];
    setObstacles([...s.obstacles]);
    addLog('WARN', 'CAMERA', `Camera detection: ${OBSTACLE_LABELS[type]} — injecting obstacle at ${aheadDist.toFixed(0)}m ahead (conf ${(confidence * 100).toFixed(0)}%)`);
  }, [addLog]);

  return {
    terrain,
    obstacles,
    ugv,
    mission,
    detections,
    terrainAnalysis,
    telemetry,
    logs,
    gpsMode,
    selectingMode,
    time,
    environment,
    landmarks,
    analytics,
    exploredArea,
    totalArea,
    loopClosures,
    featurePoints,
    totalLandmarks,
    observedLandmarks,
    handleMapClick,
    setSelectingMode,
    startMission,
    pauseMission,
    resumeMission,
    stopMission,
    resetMission,
    clearMission,
    emergencyStop,
    startDemo,
    toggleGps,
    setEnvironmentMode,
    injectObstacle,
    // Command & Control
    controlMode,
    setMode,
    manualCommand,
    sendManualCommand,
    speedScale,
    changeSpeedScale,
    commandHistory,
    connected,
    lastCommandTime,
    resumeNavigation,
  };
}
