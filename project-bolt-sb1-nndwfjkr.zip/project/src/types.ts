// Core type definitions for the UGV Navigation System
// Modular architecture — all types here allow real sensors/AI to be swapped in later

export type Vec2 = { x: number; y: number };

export type TerrainType = 'safe' | 'caution' | 'danger';

export type SurfaceType = 'road' | 'grass' | 'gravel' | 'rocks' | 'mud' | 'vegetation';

export type ObstacleType = 'rock' | 'tree' | 'ditch' | 'human' | 'vehicle' | 'animal';

export type NavigationCommand =
  | 'FORWARD'
  | 'LEFT'
  | 'RIGHT'
  | 'REVERSE'
  | 'STOP'
  | 'SLOW_DOWN';

export type ManualCommand =
  | 'FORWARD'
  | 'BACKWARD'
  | 'TURN_LEFT'
  | 'TURN_RIGHT'
  | 'ROTATE'
  | 'STOP';

export type ControlMode = 'MANUAL' | 'AUTONOMOUS';

export type CommandStatus = 'SENT' | 'EXECUTING' | 'COMPLETED' | 'BLOCKED';

export interface CommandEntry {
  id: number;
  command: ManualCommand | NavigationCommand;
  source: 'MANUAL' | 'AUTONOMOUS' | 'SYSTEM';
  status: CommandStatus;
  timestamp: string;
  ugvPos: Vec2;
  ugvHeading: number;
  ugvSpeed: number;
  blockedReason?: string;
}

export type MissionStatus =
  | 'IDLE'
  | 'PLANNING'
  | 'NAVIGATING'
  | 'OBSTACLE_DETECTED'
  | 'REPLANNING'
  | 'PAUSED'
  | 'COMPLETED'
  | 'EMERGENCY_STOP';

export type GpsMode = 'ACTIVE' | 'DENIED';

export type EnvironmentMode = 'daylight' | 'low_light' | 'shadows' | 'overcast';

export type CameraMode = 'sim' | 'live';

export type ModelStatus = 'offline' | 'loading' | 'ready' | 'error';

export type CameraDetection = {
  type: ObstacleType;
  label: string;
  confidence: number;
  bbox: { x: number; y: number; w: number; h: number };
  source: 'manual' | 'model';
  modelConnected: boolean;
};

export type RealDetection = {
  class: string;
  score: number;
  bbox: [number, number, number, number]; // [x, y, w, h] in pixels
  obstacleType: ObstacleType;
  distance: number; // estimated distance in meters
};

export type AIStats = {
  fps: number;
  inferenceMs: number;
  objectCount: number;
  topClass: string | null;
  topScore: number;
  modelStatus: ModelStatus;
};

export interface Obstacle {
  id: string;
  type: ObstacleType;
  pos: Vec2;
  radius: number;
  detected: boolean;
  confidence: number;
  distance: number;
  dynamic?: boolean;
  velocity?: Vec2;
  spawnTime?: number;
  moving?: boolean;
  safetyPriority?: number; // 1=low, 2=medium, 3=high (moving entities)
}

export interface Detection {
  id: string;
  type: ObstacleType;
  label: string;
  confidence: number;
  distance: number;
  bbox: { x: number; y: number; w: number; h: number };
  terrain: TerrainType;
  moving: boolean;
  safetyPriority: number;
}

export interface UGVState {
  pos: Vec2;
  heading: number; // radians
  speed: number; // m/s
  command: NavigationCommand;
}

export interface ConfidenceBreakdown {
  obstacle: number;
  terrain: number;
  path: number;
  localization: number;
}

export interface Telemetry {
  x: number;
  y: number;
  heading: number; // degrees
  speed: number;
  distanceTraveled: number;
  distanceRemaining: number;
  gpsMode: GpsMode;
  battery: number;
  signal: number;
  cpuLoad: number;
  aiConfidence: number;
  riskLevel: number; // 0-100
  collisionWarning: boolean;
  adaptiveSpeedLimit: number;
  confidence: ConfidenceBreakdown;
  environment: EnvironmentMode;
}

export interface GridCell {
  terrain: TerrainType;
  surface: SurfaceType;
  cost: number;
  explored: boolean;
}

export interface LogEntry {
  id: number;
  time: string;
  level: 'INFO' | 'WARN' | 'ERROR' | 'SUCCESS';
  source: string;
  message: string;
}

export interface Mission {
  pointA: Vec2 | null;
  pointB: Vec2 | null;
  status: MissionStatus;
  progress: number; // 0-100
  plannedPath: Vec2[];
  pathIndex: number;
  trajectory: Vec2[];
  startTime: number | null;
}

export interface Landmark {
  id: string;
  pos: Vec2;
  type: 'feature' | 'loop' | 'keypoint';
  observed: boolean;
}

export interface MissionAnalytics {
  missionTime: number; // seconds
  distance: number; // meters
  obstaclesDetected: number;
  routeReplans: number;
  averageSpeed: number; // m/s
  maxRisk: number; // 0-100
  collisions: number;
  completed: boolean;
}

export interface EnvironmentConfig {
  mode: EnvironmentMode;
  label: string;
  confidenceMultiplier: number;
  detectionRangeMultiplier: number;
  skyColor: string;
  groundTint: string;
  visibilityLabel: string;
}

export const OBSTACLE_SAFETY_PRIORITY: Record<ObstacleType, number> = {
  rock: 1,
  tree: 1,
  ditch: 2,
  vehicle: 3,
  human: 3,
  animal: 3,
};

export const OBSTACLE_IS_MOVING: Record<ObstacleType, boolean> = {
  rock: false,
  tree: false,
  ditch: false,
  vehicle: true,
  human: true,
  animal: true,
};

export const ENVIRONMENT_CONFIGS: Record<EnvironmentMode, EnvironmentConfig> = {
  daylight: {
    mode: 'daylight',
    label: 'DAYLIGHT',
    confidenceMultiplier: 1.0,
    detectionRangeMultiplier: 1.0,
    skyColor: '#162d3a',
    groundTint: '#1a3328',
    visibilityLabel: 'CLEAR VISIBILITY',
  },
  low_light: {
    mode: 'low_light',
    label: 'LOW LIGHT',
    confidenceMultiplier: 0.65,
    detectionRangeMultiplier: 0.6,
    skyColor: '#0a0f1a',
    groundTint: '#0d1810',
    visibilityLabel: 'REDUCED VISIBILITY',
  },
  shadows: {
    mode: 'shadows',
    label: 'SHADOWS',
    confidenceMultiplier: 0.8,
    detectionRangeMultiplier: 0.85,
    skyColor: '#121d28',
    groundTint: '#161e22',
    visibilityLabel: 'MIXED LIGHTING',
  },
  overcast: {
    mode: 'overcast',
    label: 'OVERCAST',
    confidenceMultiplier: 0.9,
    detectionRangeMultiplier: 0.95,
    skyColor: '#1a2530',
    groundTint: '#1a2a28',
    visibilityLabel: 'DIFFUSED LIGHT',
  },
};

export const SURFACE_LABELS: Record<SurfaceType, string> = {
  road: 'Road',
  grass: 'Grass',
  gravel: 'Gravel',
  rocks: 'Rocks',
  mud: 'Mud',
  vegetation: 'Vegetation',
};

export const SURFACE_COLORS: Record<SurfaceType, string> = {
  road: '#4a5568',
  grass: '#22c55e',
  gravel: '#a8a29e',
  rocks: '#78716c',
  mud: '#92400e',
  vegetation: '#166534',
};

export const SURFACE_COSTS: Record<SurfaceType, number> = {
  road: 1,
  grass: 2,
  gravel: 3,
  rocks: 10,
  mud: 8,
  vegetation: 6,
};

export const SURFACE_TERRAIN: Record<SurfaceType, TerrainType> = {
  road: 'safe',
  grass: 'safe',
  gravel: 'caution',
  rocks: 'danger',
  mud: 'caution',
  vegetation: 'caution',
};

export const COCO_TO_OBSTACLE: Record<string, ObstacleType> = {
  person: 'human',
  car: 'vehicle',
  truck: 'vehicle',
  bus: 'vehicle',
  motorcycle: 'vehicle',
  bicycle: 'vehicle',
  dog: 'animal',
  cat: 'animal',
  horse: 'animal',
  sheep: 'animal',
  cow: 'animal',
  bird: 'animal',
  bear: 'animal',
  elephant: 'animal',
  zebra: 'animal',
  giraffe: 'animal',
};

export const COCO_COLORS: Record<string, string> = {
  person: '#ef4444',
  car: '#f59e0b',
  truck: '#f59e0b',
  bus: '#f59e0b',
  motorcycle: '#f97316',
  bicycle: '#f97316',
  dog: '#a855f7',
  cat: '#a855f7',
  horse: '#a855f7',
  sheep: '#a855f7',
  cow: '#a855f7',
  bird: '#a855f7',
  bear: '#a855f7',
  elephant: '#a855f7',
  zebra: '#a855f7',
  giraffe: '#a855f7',
};
