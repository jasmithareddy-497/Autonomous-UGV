import { useState, useEffect, useRef } from 'react';
import {
  Cpu,
  Satellite,
  Activity,
  Video,
  Map as MapIcon,
  Gauge,
  Shield,
  Zap,
  Bot,
  Radio,
  BarChart3,
  Camera,
} from 'lucide-react';
import { useUGVSimulation } from '@/hooks/useUGVSimulation';
import { useCamera } from '@/hooks/useCamera';
import type { ObstacleType } from '@/types';
import { COCO_TO_OBSTACLE } from '@/types';
import CameraPanel from '@/components/CameraPanel';
import DetectionList from '@/components/DetectionList';
import NavMap from '@/components/NavMap';
import TelemetryPanel from '@/components/TelemetryPanel';
import MissionControl from '@/components/MissionControl';
import CommandControlPanel from '@/components/CommandControlPanel';
import LogConsole from '@/components/LogConsole';
import SlamPanel from '@/components/SlamPanel';
import MissionAnalyticsPanel from '@/components/MissionAnalyticsPanel';
import TerrainAnalysis from '@/components/TerrainAnalysis';

export default function App() {
  const sim = useUGVSimulation();
  const cam = useCamera();
  const [activeTab, setActiveTab] = useState<'telemetry' | 'slam' | 'analytics'>('telemetry');

  const isRunning = sim.mission.status === 'NAVIGATING';
  const showAnalytics = sim.analytics !== null;
  const isLiveCam = cam.mode === 'live' && cam.enabled;
  const aiActive = isLiveCam && cam.aiStats.modelStatus === 'ready';
  const lastInjectedRef = useRef<number>(0);

  // Auto-inject obstacles from real AI detections into the navigation system
  useEffect(() => {
    if (!aiActive || !isRunning) return;
    const now = Date.now();
    // Throttle: only inject once every 3 seconds, and only for high-confidence detections
    if (now - lastInjectedRef.current < 3000) return;
    const highConfDets = cam.realDetections.filter((d) => d.score > 0.6);
    if (highConfDets.length === 0) return;
    // Inject the highest-confidence detection as a navigation obstacle
    const top = highConfDets.reduce((max, d) => d.score > max.score ? d : max, highConfDets[0]);
    const obsType: ObstacleType = COCO_TO_OBSTACLE[top.class] ?? 'rock';
    sim.injectObstacle(obsType, top.score);
    lastInjectedRef.current = now;
  }, [aiActive, isRunning, cam.realDetections, sim]);

  // Auto-switch to analytics tab when mission completes
  useEffect(() => {
    if (sim.mission.status === 'COMPLETED' && sim.analytics) {
      setActiveTab('analytics');
    }
  }, [sim.mission.status, sim.analytics]);

  // Command & Control: listen for E-STOP event from CommandControlPanel
  useEffect(() => {
    const handler = () => sim.emergencyStop();
    window.addEventListener('ugv-estop', handler);
    return () => window.removeEventListener('ugv-estop', handler);
  }, [sim]);

  return (
    <div className="h-screen w-screen flex flex-col bg-[#0a0e14] text-slate-200 overflow-hidden">
      {/* Top Header Bar */}
      <header className="flex items-center justify-between px-4 py-2 border-b border-sky-500/15 bg-[#0d1320] flex-shrink-0">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <div className="relative">
              <Bot className="w-6 h-6 text-sky-400" />
              <div className="absolute -top-0.5 -right-0.5 w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
            </div>
            <div>
              <h1 className="text-sm font-bold text-sky-300 tracking-wider font-mono">
                UGV NAVCON
              </h1>
              <p className="text-[9px] text-slate-500 font-mono tracking-wide">
                SIH 26126 — VISION BASED AUTONOMOUS NAVIGATION
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-4">
          {/* System status indicators */}
          <div className="flex items-center gap-3">
            <StatusIndicator
              icon={<Camera className="w-3 h-3" />}
              label={isLiveCam ? 'CAM' : 'VISION'}
              active={true}
              color={isLiveCam ? 'green' : 'amber'}
            />
            <StatusIndicator
              icon={<Satellite className="w-3 h-3" />}
              label={sim.gpsMode === 'ACTIVE' ? 'GPS' : 'NO-GPS'}
              active={sim.gpsMode === 'ACTIVE'}
              color={sim.gpsMode === 'ACTIVE' ? 'green' : 'red'}
            />
            <StatusIndicator
              icon={<Cpu className="w-3 h-3" />}
              label="AI"
              active={aiActive}
              color={aiActive ? 'green' : isLiveCam ? 'amber' : 'sky'}
            />
            <StatusIndicator
              icon={<Radio className="w-3 h-3" />}
              label="LINK"
              active={sim.telemetry.signal > 60}
              color={sim.telemetry.signal > 60 ? 'green' : 'amber'}
            />
          </div>

          <div className="h-6 w-px bg-slate-700/50" />

          <div className="text-right">
            <div className="text-[10px] font-mono text-slate-500">SYSTEM TIME</div>
            <div className="text-xs font-mono font-bold text-sky-300">
              {new Date().toLocaleTimeString('en-US', { hour12: false })}
            </div>
          </div>

          {/* SIMULATION badge */}
          <div className="px-2 py-1 rounded bg-amber-500/10 border border-amber-500/30">
            <span className="text-[9px] font-mono font-bold text-amber-400 tracking-wider">
              SIMULATION
            </span>
          </div>
        </div>
      </header>

      {/* Main Content Grid */}
      <div className="flex-1 grid grid-cols-12 gap-2 p-2 overflow-hidden">
        {/* Left Column — Camera + Detections */}
        <div className="col-span-4 flex flex-col gap-2 overflow-hidden">
          {/* Camera Panel */}
          <div className="flex flex-col panel-border rounded-lg overflow-hidden flex-[1.4] min-h-0">
            <div className="flex items-center justify-between px-3 py-1.5 border-b border-sky-500/10 bg-[#0d1320]">
              <div className="flex items-center gap-2">
                <Video className="w-3.5 h-3.5 text-sky-400" />
                <span className="text-xs font-mono font-bold text-sky-300 tracking-wider">
                  CAMERA PERCEPTION
                </span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className={`w-1.5 h-1.5 rounded-full ${isRunning ? 'bg-green-400 animate-pulse' : 'bg-slate-600'}`} />
                <span className="text-[9px] font-mono text-slate-500">
                  {isRunning ? 'REC' : 'STBY'}
                </span>
              </div>
            </div>
            <div className="flex-1 relative bg-black overflow-hidden">
              <CameraPanel
                detections={sim.detections}
                ugv={sim.ugv}
                active={true}
                time={sim.time}
                environment={sim.environment}
                riskLevel={sim.telemetry.riskLevel}
                collisionWarning={sim.telemetry.collisionWarning}
                cameraMode={cam.mode}
                cameraEnabled={cam.enabled}
                cameraStream={cam.stream}
                cameraError={cam.error}
                realDetections={cam.realDetections}
                aiStats={cam.aiStats}
                videoRef={cam.videoRef}
                onEnableCamera={cam.enable}
                onDisableCamera={cam.disable}
              />
            </div>
          </div>

          {/* Detection List */}
          <div className="flex flex-col panel-border rounded-lg overflow-hidden flex-1 min-h-0">
            <DetectionList
              detections={sim.detections}
              cameraMode={cam.mode}
              realDetections={cam.realDetections}
              aiStats={cam.aiStats}
            />
          </div>
        </div>

        {/* Center Column — Map + Terrain + Log */}
        <div className="col-span-5 flex flex-col gap-2 overflow-hidden">
          <div className="flex flex-col panel-border rounded-lg overflow-hidden flex-1 min-h-0">
            <div className="flex items-center justify-between px-3 py-1.5 border-b border-sky-500/10 bg-[#0d1320]">
              <div className="flex items-center gap-2">
                <MapIcon className="w-3.5 h-3.5 text-sky-400" />
                <span className="text-xs font-mono font-bold text-sky-300 tracking-wider">
                  NAVIGATION MAP — SLAM
                </span>
              </div>
              <div className="flex items-center gap-3 text-[9px] font-mono">
                <span className="flex items-center gap-1 text-green-400">
                  <div className="w-2 h-2 rounded-sm bg-green-800/60" /> SAFE
                </span>
                <span className="flex items-center gap-1 text-amber-400">
                  <div className="w-2 h-2 rounded-sm bg-amber-800/60" /> CAUTION
                </span>
                <span className="flex items-center gap-1 text-red-400">
                  <div className="w-2 h-2 rounded-sm bg-red-800/60" /> DANGER
                </span>
              </div>
            </div>
            <div className="flex-1 relative bg-black overflow-hidden">
              <NavMap
                terrain={sim.terrain}
                obstacles={sim.obstacles}
                ugv={sim.ugv}
                mission={sim.mission}
                gpsMode={sim.gpsMode}
                selectingMode={sim.selectingMode}
                time={sim.time}
                onMapClick={sim.handleMapClick}
                exploredRadius={20}
                landmarks={sim.landmarks}
                riskLevel={sim.telemetry.riskLevel}
              />
            </div>
          </div>

          {/* Terrain Analysis */}
          <div className="panel-border rounded-lg overflow-hidden flex-shrink-0">
            <TerrainAnalysis terrainAnalysis={sim.terrainAnalysis} />
          </div>

          {/* Log Console */}
          <div className="flex flex-col panel-border rounded-lg overflow-hidden h-32 flex-shrink-0">
            <LogConsole logs={sim.logs} />
          </div>
        </div>

        {/* Right Column — Controls + Telemetry/SLAM/Analytics */}
        <div className="col-span-3 flex flex-col gap-2 overflow-y-auto">
          {/* Mission Control */}
          <div className="panel-border rounded-lg overflow-hidden flex-shrink-0">
            <div className="flex items-center gap-2 px-3 py-1.5 border-b border-sky-500/10 bg-[#0d1320]">
              <Zap className="w-3.5 h-3.5 text-sky-400" />
              <span className="text-xs font-mono font-bold text-sky-300 tracking-wider">
                MISSION CONTROL
              </span>
            </div>
            <MissionControl
              mission={sim.mission}
              ugvPos={sim.ugv.pos}
              distanceToDestination={sim.telemetry.distanceRemaining}
              onSelectDestination={() => sim.setSelectingMode('destination')}
              onStart={sim.mission.status === 'PAUSED' ? sim.resumeMission : sim.startMission}
              onPause={sim.pauseMission}
              onStop={sim.stopMission}
              onClear={sim.clearMission}
              onDemo={sim.startDemo}
              onEmergencyStop={sim.emergencyStop}
              selectingMode={sim.selectingMode}
              environment={sim.environment}
              onEnvironmentChange={sim.setEnvironmentMode}
              gpsMode={sim.gpsMode}
            />
          </div>

          {/* Command & Control Panel */}
          <div className="panel-border rounded-lg overflow-hidden flex-shrink-0">
            <div className="flex items-center gap-2 px-3 py-1.5 border-b border-sky-500/10 bg-[#0d1320]">
              <Radio className="w-3.5 h-3.5 text-sky-400" />
              <span className="text-xs font-mono font-bold text-sky-300 tracking-wider">
                UGV COMMAND & CONTROL
              </span>
            </div>
            <CommandControlPanel
              controlMode={sim.controlMode}
              onModeChange={sim.setMode}
              manualCommand={sim.manualCommand}
              onManualCommand={sim.sendManualCommand}
              speedScale={sim.speedScale}
              onSpeedChange={sim.changeSpeedScale}
              commandHistory={sim.commandHistory}
              ugv={sim.ugv}
              mission={sim.mission}
              telemetry={sim.telemetry}
              connected={sim.connected}
              lastCommandTime={sim.lastCommandTime}
              obstacleAhead={sim.telemetry.riskLevel > 30 && sim.detections.length > 0}
              onResumeNavigation={sim.resumeNavigation}
            />
          </div>

          {/* Tabbed Panel: Telemetry / SLAM / Analytics */}
          <div className="panel-border rounded-lg overflow-hidden flex-1">
            <div className="flex border-b border-sky-500/10 bg-[#0d1320]">
              <button
                onClick={() => setActiveTab('telemetry')}
                className={`flex items-center gap-1.5 px-2 py-1.5 text-xs font-mono font-bold tracking-wider transition-all ${
                  activeTab === 'telemetry'
                    ? 'text-sky-300 border-b-2 border-sky-400'
                    : 'text-slate-500 hover:text-slate-400'
                }`}
              >
                <Gauge className="w-3 h-3" /> TEL
              </button>
              <button
                onClick={() => setActiveTab('slam')}
                className={`flex items-center gap-1.5 px-2 py-1.5 text-xs font-mono font-bold tracking-wider transition-all ${
                  activeTab === 'slam'
                    ? 'text-sky-300 border-b-2 border-sky-400'
                    : 'text-slate-500 hover:text-slate-400'
                }`}
              >
                <Activity className="w-3 h-3" /> SLAM
              </button>
              {showAnalytics && (
                <button
                  onClick={() => setActiveTab('analytics')}
                  className={`flex items-center gap-1.5 px-2 py-1.5 text-xs font-mono font-bold tracking-wider transition-all ${
                    activeTab === 'analytics'
                      ? 'text-green-300 border-b-2 border-green-400'
                      : 'text-green-500/60 hover:text-green-400'
                  }`}
                >
                  <BarChart3 className="w-3 h-3" /> STATS
                </button>
              )}
            </div>

            <div className="overflow-y-auto" style={{ maxHeight: 'calc(100vh - 420px)' }}>
              {activeTab === 'telemetry' && (
                <TelemetryPanel
                  telemetry={sim.telemetry}
                  command={sim.ugv.command}
                  cameraMode={cam.mode}
                  cameraEnabled={cam.enabled}
                  missionStatus={sim.mission.status}
                  aiStats={cam.aiStats}
                />
              )}
              {activeTab === 'slam' && (
                <SlamPanel
                  gpsMode={sim.gpsMode}
                  status={sim.mission.status}
                  exploredArea={sim.exploredArea}
                  totalArea={sim.totalArea}
                  loopClosures={sim.loopClosures}
                  featurePoints={sim.featurePoints}
                  totalLandmarks={sim.totalLandmarks}
                  observedLandmarks={sim.observedLandmarks}
                />
              )}
              {activeTab === 'analytics' && sim.analytics && (
                <MissionAnalyticsPanel analytics={sim.analytics} />
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Status Bar */}
      <footer className="flex items-center justify-between px-4 py-1 border-t border-sky-500/15 bg-[#0d1320] text-[10px] font-mono text-slate-500 flex-shrink-0">
        <div className="flex items-center gap-4">
          <span className="flex items-center gap-1">
            <Shield className="w-2.5 h-2.5 text-sky-500" />
            NAVCON v3.0
          </span>
          <span>A* PATHFINDING</span>
          <span>{aiActive ? 'COCO-SSD LIVE AI' : isLiveCam ? 'LIVE CAMERA' : 'YOLO-SIM v3 DETECTION'}</span>
          <span>VISUAL ODOMETRY</span>
          <span>ADAPTIVE SPEED</span>
        </div>
        <div className="flex items-center gap-4">
          <span className="text-sky-500/60">SIH PROBLEM STATEMENT 26126</span>
          <span className="flex items-center gap-1">
            <div className="w-1 h-1 rounded-full bg-green-400 animate-pulse" />
            OPERATIONAL
          </span>
        </div>
      </footer>
    </div>
  );
}

function StatusIndicator({
  icon,
  label,
  active,
  color,
}: {
  icon: React.ReactNode;
  label: string;
  active: boolean;
  color: 'green' | 'red' | 'sky' | 'amber';
}) {
  const colors = {
    green: active ? 'text-green-400 border-green-500/30 bg-green-950/20' : 'text-slate-600 border-slate-700/30 bg-slate-900/20',
    red: active ? 'text-red-400 border-red-500/30 bg-red-950/20' : 'text-slate-600 border-slate-700/30 bg-slate-900/20',
    sky: active ? 'text-sky-400 border-sky-500/30 bg-sky-950/20' : 'text-slate-600 border-slate-700/30 bg-slate-900/20',
    amber: active ? 'text-amber-400 border-amber-500/30 bg-amber-950/20' : 'text-slate-600 border-slate-700/30 bg-slate-900/20',
  };

  return (
    <div className={`flex items-center gap-1 px-2 py-0.5 rounded border ${colors[color]}`}>
      {icon}
      <span className="text-[9px] font-mono font-bold tracking-wider">{label}</span>
    </div>
  );
}
